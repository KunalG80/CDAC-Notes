namespace Tourism.Models;

public readonly record struct Candidate2(decimal Id, string Name , string Job , decimal Department);
